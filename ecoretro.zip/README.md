# EcoRetro — localhost

Landing page sesuai preview: hijau–putih, latar gelap, ilustrasi kos isometrik, animasi GSAP, dan parallax saat scroll pada desktop.

## Cara menjalankan di Windows

1. Ekstrak seluruh ZIP terlebih dahulu.
2. Buka folder `ecoretro-local`.
3. Klik dua kali `start-localhost.bat` (memerlukan Python 3).
4. Browser membuka `http://localhost:8080`. Biarkan terminal terbuka.
5. Tekan `Ctrl+C` di terminal untuk menghentikan server.

Alternatif melalui terminal di folder ini:

    python server.py

Jika port sudah dipakai:

    python server.py --port 8081

Tanpa Python: buka `index.html` langsung di browser. Halaman dan animasi tidak memerlukan proses build, npm, atau koneksi internet. Untuk penggunaan localhost tetap gunakan server statis.

## Isi paket

- `index.html`: struktur dan teks halaman.
- `styles.css`: layout responsif dan warna.
- `app.js`: navigasi mobile, tab grafik, modal, GSAP, dan ScrollTrigger.
- `assets/`: ilustrasi dan ikon SVG seperti pada preview.
- `vendor/`: GSAP 3.14.2 dan ScrollTrigger 3.14.2, tersimpan lokal.
- `server.py` dan `start-localhost.bat`: server lokal, terikat ke 127.0.0.1.

## Interaksi

- Menu atas menuju bagian halaman; menu mobile dapat dibuka/ditutup.
- Tab mingguan/bulanan mengganti grafik ilustratif.
- FAQ dapat dibuka/ditutup.
- Tombol konsultasi membuka informasi prototipe, belum mengirim data.
- Parallax scroll pada desktop; gerakan mengikuti pointer untuk perangkat dengan mouse.
- Animasi menghormati pengaturan sistem `prefers-reduced-motion`.

## Status konten

Ini prototipe business plan, belum terhubung dengan sensor, backend, formulir aktif, atau layanan konsultasi. Data monitoring adalah ilustrasi. Tidak ada klaim penghematan atau testimoni pelanggan aktual.

## Dependensi dan lisensi

GSAP dan ScrollTrigger 3.14.2: https://gsap.com/ dan https://gsap.com/standard-license/ . Pemberitahuan dependensi ada di `vendor/GSAP-NOTICE.txt`; header asli dipertahankan dalam berkas vendor. Dokumentasi: https://gsap.com/docs/v3/Plugins/ScrollTrigger/ . Tidak ada request jaringan saat halaman digunakan.
